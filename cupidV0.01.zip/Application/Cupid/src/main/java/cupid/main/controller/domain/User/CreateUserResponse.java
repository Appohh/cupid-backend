package cupid.main.controller.domain.User;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateUserResponse {
   private Integer id;
}
