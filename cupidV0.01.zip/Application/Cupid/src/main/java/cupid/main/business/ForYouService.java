package cupid.main.business;

public interface ForYouService {

}
