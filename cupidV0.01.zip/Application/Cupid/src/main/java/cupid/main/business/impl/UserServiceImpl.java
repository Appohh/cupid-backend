package cupid.main.business.impl;

import cupid.main.business.UserService;
import cupid.main.controller.domain.User.CreateUserRequest;
import cupid.main.controller.domain.User.CreateUserResponse;
import cupid.main.controller.domain.User.User;
import cupid.main.business.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {
    UserRepository userRepository;
    @Override
    public Optional<CreateUserResponse> CreateUser(CreateUserRequest request) {
        if (userRepository.userExist(request.getEmail(), request.getPhone())) {
            return Optional.empty();
        }
        return userRepository.createUser(request);
    }

    @Override
    public Optional<User> GetUserById(Integer id) {
        return userRepository.getUserById(id);
    }
}
