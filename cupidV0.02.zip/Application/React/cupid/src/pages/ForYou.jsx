
function ForYou() {

  return (
    <>
    <h1>For You</h1>



    </>
  )
}

export default ForYou
