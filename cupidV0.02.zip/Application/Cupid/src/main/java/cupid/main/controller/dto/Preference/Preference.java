package cupid.main.controller.dto.Preference;

public class Preference {
}
