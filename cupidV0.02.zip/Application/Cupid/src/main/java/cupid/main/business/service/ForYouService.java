package cupid.main.business.service;

public interface ForYouService {

}
