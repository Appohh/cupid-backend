package cupid.main.controller.dto.User;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateUserResponse {
   private Integer id;
}
