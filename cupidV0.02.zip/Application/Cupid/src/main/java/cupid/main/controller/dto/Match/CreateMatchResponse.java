package cupid.main.controller.dto.Match;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateMatchResponse {
    Integer id;
}
