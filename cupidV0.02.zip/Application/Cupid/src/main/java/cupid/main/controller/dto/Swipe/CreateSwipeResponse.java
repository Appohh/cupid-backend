package cupid.main.controller.dto.Swipe;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateSwipeResponse {
    Integer id;
}
