package cupid.main.persistence.iJpa;

public interface iSwipeJpa {
}
