package cupid.main.domain.Dto.Match;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateMatchResponse {
    Integer id;
}
