package cupid.main.domain.Dto.Swipe;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateSwipeResponse {
    Integer id;
}
